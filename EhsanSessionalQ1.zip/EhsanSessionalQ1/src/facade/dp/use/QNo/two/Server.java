package facade.dp.use.QNo.two;

public interface Server {
	void boot();
    void  shutdown();
}
