module labAssignmentPrototype {
}