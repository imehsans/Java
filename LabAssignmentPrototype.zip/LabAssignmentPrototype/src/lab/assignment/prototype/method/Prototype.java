package lab.assignment.prototype.method;

public interface Prototype {
	public AccessControl clone() throws CloneNotSupportedException;

}
