package decorator.dp.sess.qno.one;

public interface Cake {

	public String getDesc();
	public double getPrice();
}
