package decorator.dp.sess.qno.one;

public class CoffeCake implements Cake{
			@Override
			public String getDesc() {
				return "Coffeecake (250.0)";
			}
			@Override
			public double getPrice() {
				return 250.0;
			}
		}

